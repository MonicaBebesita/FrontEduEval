import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GestionarCompetenciasTemplateComponent } from '../../../components/templates/gestionar-competencias-template/gestionar-competencias-template.component';

@Component({
  standalone: true,
  selector: 'app-gestionar-competencias-programa',
  imports: [CommonModule, GestionarCompetenciasTemplateComponent],
  template: `
    <app-gestionar-competencias-template
      [titulo]="'Competencias del Programa'"
      [competencias]="competencias"
      [routerLink]="['/programa/crearCP']"
      rutaRA="/programa/RAprograma"
      rutaEditar="/programa/editarCP"
      rutaVer="/programa/verCP"
      (eliminarCompetencia)="eliminarCompetencia($event)"
    >
    </app-gestionar-competencias-template>
  `,
})
export class GestionarCompetenciasProgramaComponent {
  competencias = [
    { id: 1, descripcion: 'Resolver problemas', nivel: 'avanzado' },
    { id: 2, descripcion: 'Pensamiento crítico', nivel: 'básico' },
  ];

  eliminarCompetencia(id: number) {
    console.log('Eliminar competencia con ID:', id);
    this.competencias = this.competencias.filter((c) => c.id !== id);
  }
}
